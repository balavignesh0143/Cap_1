package com.capgemini.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.exceptions.CapStoreException;
import com.capgemini.capstore.service.IGetAccounts;
import com.capgemini.capstore.service.IPasswordOperation;
import com.capgemini.capstore.service.ISignIn;
import com.capgemini.capstore.service.ISignUp;

@RestController
@RequestMapping("/merchant")
@CrossOrigin(origins = "http://localhost:4200")
public class MerchantController {
	@Autowired
	ISignUp signUpService;

	@Autowired
	ISignIn signInService;

	@Autowired
	IPasswordOperation passwordOperation;

	@Autowired
	IGetAccounts getAccountsService;

	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping(value = "/create")
	public Merchant createAccount(@RequestBody Merchant merchant) {
		return signUpService.createAccount(merchant);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(value = "/getAccount/{merchantId}")
	public Merchant viewById(@PathVariable long merchantId) {
		return signInService.findByMerchantId(merchantId);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@PutMapping(value = "/changePassword/{merchantId}/{oldPassword}/{newPassword}")
	public boolean changePassword(@PathVariable long merchantId, @PathVariable String oldPassword,
			@PathVariable String newPassword) throws CapStoreException {
		return passwordOperation.changePasswordMerchant(merchantId, oldPassword, newPassword);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@PutMapping(value = "/forgetPassword/{merchantId}/{merchantQuestion}/{merchantAnswer}/{newPassword}")
	public boolean forgetPassword(@PathVariable long merchantId, @PathVariable int merchantQuestion,
			@PathVariable String merchantAnswer, @PathVariable String newPassword) throws CapStoreException {
		return passwordOperation.forgetPassword(merchantId, merchantQuestion, merchantAnswer, newPassword);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(value = "/getAccounts")
	public List<Merchant> getAccounts() {
		return getAccountsService.getMerchantAccounts();
	}

}
