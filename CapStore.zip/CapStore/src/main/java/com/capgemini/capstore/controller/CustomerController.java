package com.capgemini.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.exceptions.CapStoreException;
import com.capgemini.capstore.service.IGetAccounts;
import com.capgemini.capstore.service.IPasswordOperation;
import com.capgemini.capstore.service.ISignIn;
import com.capgemini.capstore.service.ISignUp;

@RestController
@RequestMapping("/customer")
@CrossOrigin(origins = "http://localhost:4200")
public class CustomerController {
	@Autowired
	ISignUp signUpService;

	@Autowired
	ISignIn signInService;

	@Autowired
	IPasswordOperation passwordOperation;

	@Autowired
	IGetAccounts getAccountsService;

	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping(value = "/create")
	public Customer createAccount(@RequestBody Customer customer) {
		return signUpService.createAccount(customer);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(value = "/getAccount/{customerId}")
	public Customer viewById(@PathVariable long customerId) {
		return signInService.findByCustomerId(customerId);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@PutMapping(value = "/changePassword/{customerId}/{oldPassword}/{newPassword}")
	public boolean changePassword(@PathVariable long customerId, @PathVariable String oldPassword,
			@PathVariable String newPassword) throws CapStoreException {
		return passwordOperation.changePasswordCustomer(customerId, oldPassword, newPassword);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@PutMapping(value = "/forgetPassword/{customerId}/{customerQuestion}/{customerAnswer}/{newPassword}")
	public boolean forgetPassword(@PathVariable long customerId, @PathVariable Integer customerQuestion,
			@PathVariable String customerAnswer, @PathVariable String newPassword) throws CapStoreException {
		return passwordOperation.forgetPassword(customerId, customerQuestion, customerAnswer, newPassword);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(value = "/forgetId/{customerContactNo}")
	public long findByContactNo(@PathVariable String customerContactNo) {
		return passwordOperation.findByCustomerContactNo(customerContactNo);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(value = "/getAccounts")
	public List<Customer> getAccounts() {
		return getAccountsService.getCustomerAccounts();
	}
}
