package com.capgemini.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Admin;
import com.capgemini.capstore.service.IGetAccounts;
import com.capgemini.capstore.service.ISignIn;
import com.capgemini.capstore.service.ISignUp;

@RestController
@RequestMapping("/admin")
public class AdminController {
	@Autowired
	ISignUp signUpService;

	@Autowired
	ISignIn signInService;

	@Autowired
	IGetAccounts getAccountsService;

	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping(value = "/create")
	public Admin createAccount(@RequestBody Admin admin) throws Exception {
		return signUpService.createAccount(admin);
	}

	/*
	 * @GetMapping(value="/viewAll") public List<AdminEntity> viewAllAdmin() {
	 * return adminService.viewAllAdmin(); }
	 */

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(value = "/getAccount/{adminId}")
	public Admin findByAdminId(@PathVariable long adminId) throws Exception {
		return signInService.findByAdminId(adminId);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(value = "/getAccounts")
	public List<Admin> getAccounts() {
		return getAccountsService.getAdminsAccounts();
	}
}
