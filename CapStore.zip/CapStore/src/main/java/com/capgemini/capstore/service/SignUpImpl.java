package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Admin;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.dao.IAdminDao;
import com.capgemini.capstore.dao.ICustomerDao;
import com.capgemini.capstore.dao.IMerchantDao;
import com.capgemini.capstore.util.Encryption;
import com.capgemini.capstore.util.Status;

@Service
public class SignUpImpl implements ISignUp {

	@Autowired
	IAdminDao adminDao;

	@Autowired
	ICustomerDao customerDao;

	@Autowired
	IMerchantDao merchantDao;

	@Override
	public Admin createAccount(Admin admin) throws Exception {
		admin.setAdminPassword(Encryption.encrypt(admin.getAdminPassword()));
		adminDao.save(admin);
		return admin;
	}

	@Override
	public Customer createAccount(Customer customer) {
		customer.setCustomerPassword(Encryption.encrypt(customer.getCustomerPassword()));
		customer.setCustomerStatus(Status.ACTIVE);
		customerDao.save(customer);
		return customerDao.findById(customer.getCustomerId()).get();
	}

	@Override
	public Merchant createAccount(Merchant merchant) {
		merchant.setMerchantPassword(Encryption.encrypt(merchant.getMerchantPassword()));
		merchant.setMerchantStatus(Status.ACTIVE);
		merchantDao.save(merchant);
		return merchantDao.findById(merchant.getMerchantId()).get();
	}
}
