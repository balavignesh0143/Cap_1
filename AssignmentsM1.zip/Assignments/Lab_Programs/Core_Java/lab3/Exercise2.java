package lab3;

import java.util.Arrays;
import java.util.Scanner;

public class Exercise2 {
	public static String sortString(String inputString)
	{
		char tempArray[]=inputString.toCharArray();
		Arrays.sort(tempArray);
		return new String(tempArray);
	}
	public static void main(String[] args) {
		String str;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string:");
		str=sc.nextLine();
		str=sortString(str);
		int n=str.length();
		String str1="";
		String str2="";
		String str3="";
		String str4="";
		String s1=null,s2=null;
		String s3=null,s4=null;
		if(n%2==0)
		{
			for(int i=0;i<n;i++)
			{
				if(i<n/2)
				{
					str1+=str.charAt(i);
					s1=str1.toUpperCase();
				}
				else
				{
					str2+=str.charAt(i);
					s2=str2.toLowerCase();
				}
			}
			System.out.println(s1);
			System.out.println(s2);
		}
		else
		{
			for(int i=0;i<n;i++)
			{
				if(i<n/2+1)
				{
					str3+=str.charAt(i);
					s3=str3.toUpperCase();
				}
				else
				{
					str4+=str.charAt(i);
					s4=str4.toLowerCase();
				}
			}
			System.out.println(s3);
			System.out.println(s4);
		}
		sc.close();
	}

}
