package lab3;

import java.util.Scanner;

public class Exercise1 {
	int getSecondSmallest(int a[])
	{
		int temp;		
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		return a[1];
	}
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no.of elements in array:");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter the elements:");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		Exercise1 e=new Exercise1();
		int b=e.getSecondSmallest(a);
		System.out.println("Second Smallest: "+b);
		sc.close();
	}

}
