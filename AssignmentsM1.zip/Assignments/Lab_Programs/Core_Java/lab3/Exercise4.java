package lab3;
import java.util.Scanner;
public class Exercise4 {
	static void getOccur(String s)
	{
		int count[]=new int[256];
		int len=s.length();
		for(int i=0;i<len;i++)
		{
			count[s.charAt(i)]++;
		}
		char ch[]=new char[s.length()];
		for(int i=0;i<len;i++)
		{
			ch[i]=s.charAt(i);
			int f=0;
			for(int j=0;j<=i;j++)
			{
				if(s.charAt(i)==ch[j])
					f++;
			}
			if(f==1)
			{
				System.out.println("Number of occurence of "+s.charAt(i)+" is "+count[s.charAt(i)]);
			}
		}
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string:");
		String s=sc.nextLine();
		getOccur(s);
		sc.close();
	}
}
