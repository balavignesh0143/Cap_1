package lab1;

import java.util.Scanner;

public class Exercise2 {
	static int calculateDifference(int n)
	{
		int sum;
		int sum1=0;
		int sum2=0;
		for(int i=1;i<=n;i++)
		{
			sum1=sum1+(i*i);
		}
		for(int j=1;j<=n;j++)
		{
			sum2=sum2+j;
		}
		sum2=sum2*sum2;
		sum=sum1-sum2;
		return sum;
	
	}
		public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the limit:");
		int n=sc.nextInt();
		System.out.println("Difference:"+calculateDifference(n));
		sc.close();
	}

}
