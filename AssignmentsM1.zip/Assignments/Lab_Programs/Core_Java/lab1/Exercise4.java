package lab1;

import java.util.Scanner;

public class Exercise4 {
	static boolean checkNumber(int n)
	{
		while(n>1)
		{
			if(n%2!=0)
			{
				return false;
			}
		n=n/2;
		}
		
		return true;
	}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the number:");
	int n=sc.nextInt();
	System.out.println(checkNumber(n));
	if(checkNumber(n))
		System.out.println(n+" is power of 2");
	else
		System.out.println(n+" is not a power of 2");
	sc.close();
}
}
