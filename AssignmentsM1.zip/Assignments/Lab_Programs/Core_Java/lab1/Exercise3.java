package lab1;

import java.util.Scanner;

public class Exercise3 {
	static boolean checkNumber(int number)
	{
		boolean a=false;
		int a1=number%10;
		number=number/10;
		while(number>0)
		{
			if(a1<=number%10)
			{
				a=true;
				break;
			}
			a1=number%10;
			number=number/10;
		}
		if(a)
		{
			System.out.println("Not an increasing number");
			return false;
		}
		else
		{
			System.out.println("Increasing number");
			return true;
		}
		
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the numbers:");
		int number=sc.nextInt();
		System.out.println(checkNumber(number));
		sc.close();
	}

}
