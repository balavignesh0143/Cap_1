package lab5;
import java.util.Scanner;
@SuppressWarnings("serial")
class primeException extends Exception
{
	@SuppressWarnings("unused")
	private int limit;
	public void primeExcpetion(int limit)
	{
		this.limit=limit;
	}
}
public class Exercise3 {
	static void number(int limit)throws primeException
	{
		System.out.println("Prime numbers are");
		for(int i=2;i<limit;i++)
		{
			int temp=0;
			for(int j=2;j<i;j++)
			{
				if(i%j==0)
				temp=1;
			}
			if(temp==0)
				System.out.println(+i);
		}
	}
	public static void main(String arg[]) throws primeException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the limit:");
		int limit=sc.nextInt();
		Exercise3.number(limit);
		sc.close();
	}
}
