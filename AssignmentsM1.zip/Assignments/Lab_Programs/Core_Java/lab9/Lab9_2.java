package lab9;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Lab9_2 
{
static final int MAX_CHAR = 256;
@SuppressWarnings("rawtypes")
public static void countCharacters(char b[])
  {
	HashMap<Character,Integer> charCountMap = new HashMap<Character,Integer>(); 
    for (char c : b) 
	 { 
	  if (charCountMap.containsKey(c))
		{ 
          charCountMap.put(c, charCountMap.get(c) + 1); 
		} 
		else 
		{ 
          charCountMap.put(c, 1); 
		} 
	} 
  for (Map.Entry entry : charCountMap.entrySet())
   { 
	System.out.println(entry.getKey() + " " + entry.getValue()); 
	} 
}
public static void main(String[] args) 
 {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter the Number of Characters:");
	int character = scan.nextInt();
	char ch[] = new char[character];
    System.out.println("The Number of Characters present are:-");
	for(int word=0; word<character ; word++)
	{
	 ch[word] = scan.next().charAt(0);
	}
	countCharacters(ch);
	scan.close();
	}
}
