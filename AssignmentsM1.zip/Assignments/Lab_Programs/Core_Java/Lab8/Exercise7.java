package Lab8;
import java.util.Scanner;
public class Exercise7 {
	public static void main(String[] args) {
		 boolean valid=false;
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter the name:");
		 String name=sc.nextLine();
		 name +="_job";
		 int i=name.indexOf("_");
		 String s=name.substring(0,i);
		 System.out.println(s);
		 valid=validate(s);
		 if(valid==true)
		 {
			 System.out.println("valid name "+name);
		 }
		 else
		 {
			 System.out.println("Invalid name");
		 }
		 sc.close();
	}
	static boolean validate(String name)
	{
		boolean res=false;
		if(name.length()<8)
		{
			res=false;
		}
		else
		{
			res=true;
		}
		return res;
	}
}
