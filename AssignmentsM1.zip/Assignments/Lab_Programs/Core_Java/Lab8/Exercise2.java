package Lab8;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class Exercise2 {
	public static void main(String[] args) throws IOException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the file name:");
		String fn=sc.nextLine();
		fn +=".txt";
		File f=new File(fn);
		FileWriter fw=new FileWriter(f);
		fw.write("a");
		fw.write("b");
		fw.write("c");
		fw.write("d");
		fw.flush();
		fw.close();
		sc.close();
		
	    FileReader r=new FileReader(f);
	    int i=r.read();
	    int line=1;
	    if(f.exists())
	    {
	    	while(i!=-1)
	    	{
	    		System.out.println("Line number: "+line);
	    		System.out.println((char) i);
	    		i=r.read();
	    		line++;
	    	}
	    	r.close();
	    }
	}
}
