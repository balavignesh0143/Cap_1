package labExercise;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/BusinessLogicServlet")
public class BusinessLogicServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		if(request.getParameter("name").equals("bala") && request.getParameter("pass").equals("6798")) {
			out.print("<html><body><h1>Success</h1></body></html>");
		}
		else
		{
			out.print("<html><body><h1>Failure</h1></body></html>");
		}
			
	}

}
