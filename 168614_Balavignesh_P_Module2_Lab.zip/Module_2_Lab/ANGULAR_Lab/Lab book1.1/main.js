"use strict";
exports.__esModule = true;
var smartPhone_1 = require("./smartPhone");
var basicPhone_1 = require("./basicPhone");
var arry = new Array();
var basicph = new basicPhone_1.Basicphone("Keypad");
arry.push(basicph);
var smartph = new smartPhone_1.Smartphone("Without keypad");
arry.push(smartph);
for (var i = 0; i < arry.length; i++) {
    arry[i].printMobileDetails();
}
