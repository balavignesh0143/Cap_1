import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeserviceService {

  http:HttpClient;//object creation for http client module
  employee:Employee[]=[];//object creation for employee class

  constructor(http:HttpClient) { //passing the values into constructor
    this.http=http;
    this.fetchEmployee();
  }

  fetched:boolean=false;//initialize the value as false

  fetchEmployee()//fetching the data from json file
  {
    this.http.get('./assets/Employee.json')//path of json file
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }

  getEmployee():Employee[]//return the employee class details
  {
    return this.employee;
  }

  convert(data:any)//converting the data
  {
    for(let emp of data)//local object creation
    {
      let emp1=new Employee(emp.id,emp.name,emp.email,emp.phone);
      this.employee.push(emp1);
    }
  }

  delete(id:number)//function for delete operation
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.employee.length;i++)
    {
      let emp2=this.employee[i];
      if(id==emp2.id)//checking the condition for deleting the particular row
      {
        foundIndex=i;
        break;
      }
    }
    this.employee.splice(foundIndex,1);//splicing the value
  }

  add(emp3:Employee){//add function using for adding the details
    this.employee.push(emp3);//push the data into json file
  }
}

export class Employee{//class for declaring the json file details
  id:number;//declaring
  name:string;
  email:any;
  phone:number;
    constructor( id:number,name:string,email:any,phone:number)//passing the values into the parameters
    {
      this.id=id;
      this.name=name;
      this.email=email;
      this.phone=phone;
    }
}