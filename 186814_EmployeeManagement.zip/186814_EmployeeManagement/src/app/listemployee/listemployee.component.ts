import { Component, OnInit } from '@angular/core';
import { EmployeeserviceService, Employee } from '../employeeservice.service';

@Component({
  selector: 'emplist',
  templateUrl: './listemployee.component.html',
  styleUrls: ['./listemployee.component.css']
})
export class ListemployeeComponent implements OnInit {

  service:EmployeeserviceService;//object creation of service class
  employee:Employee[]=[];//object creation of employee class
  constructor(service:EmployeeserviceService) { //passing the values into the constructor
    this.service=service;
  }

  delete(id:number)//function for delete the particular data
  {
    this.service.delete(id);//passing the values here to service
    this.employee=this.service.getEmployee();//passing the values from service class to here
    alert("Are you sure to delete?");//alert box for asking the option to delete
  }

  ngOnInit() {//using for callback
    this.service.fetchEmployee();
    this.employee=this.service.getEmployee();
  }

}
