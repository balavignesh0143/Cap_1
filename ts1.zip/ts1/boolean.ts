let yes:boolean=true;
let no:boolean=false;
let a:string="Bala";
let b:string="Vignesh";
console.log(yes);
console.log(no);
console.log(a);
console.log(b);