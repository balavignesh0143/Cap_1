class Company{
    readonly country:string="India";
    readonly name:string;
    constructor(_name:string){
        this.name=_name;    
    }
    showDetails(){
        console.log(this.name+" : "+this.country);
    }
}
let c1=new Company("Capgemini");
c1.showDetails();//dot net tricks innvoation : india
//c1.name="Infosys";//error name can be initialized only capgemini