function add() {
    var x = 10;
    if (x != 0) {
        var b = 5;
        b = x + b;
    }
    return b;
}
console.log(add());
