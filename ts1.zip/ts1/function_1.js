function add(x, y) {
    return x + y;
}
var sum = function (x, y) {
    return x + y;
};
console.log(add(14, 15));
console.log(sum(12, 13));
var sum1 = function (x, y) { return x + y; };
console.log(sum1(123, 321));
var sum2 = function (x, y) {
    return x + y;
};
console.log(sum2(123, 234));
var sum3 = function (x, y) { return x + y; };
console.log(sum3(123, 324));
var sum4 = function () { return console.log("function with out return type"); };
console.log(sum4());
