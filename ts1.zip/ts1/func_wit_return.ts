function add(a,b)
{
    return a+b;
}
var sum=add(10,20);
var sum1=add("welcome",10);
console.log(sum);
console.log(sum1);
var x:number;
function add1(a:number,b:number)
{
    return a+b;
}
var sum2=add1(100,200);
console.log(sum2);
function add2(a:number,b:number,c?)
{
    return a+b+c;
}
var sum3=add2(100,200);
var sum4=add2(100,200,300);
console.log(sum3);
console.log(sum4);
function add3(a,b,c,d?:number)
{
    return a+b+c+d;
}
var sum5=add3(11,22,33,44);
console.log(sum5);