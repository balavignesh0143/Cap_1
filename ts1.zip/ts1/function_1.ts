function add(x:number,y:number):number{
    return x+y;
}
let sum=function(x:number,y:number):number{
    return x+y;
}
console.log(add(14,15));
console.log(sum(12,13));
let sum1=(x:number,y:number)=>x+y;
console.log(sum1(123,321));
let sum2=(x:number,y:number)=>{
    return x+y;
}
console.log(sum2(123,234));
let sum3=(x,y)=>x+y;
console.log(sum3(123,324));
let sum4=()=>console.log("function with out return type");
console.log(sum4());