var firstname = "Balavignesh";
var site = "www.hsengivalab.com"; //string concatenation
var str = "Hello, My Name is " + firstname +
    " and My Site " + site;
console.log(str); //string interpolation and multiline
var str2 = "Hello, \nMy Name is " + firstname + " and \nMy Site is " + site;
console.log(str2);
