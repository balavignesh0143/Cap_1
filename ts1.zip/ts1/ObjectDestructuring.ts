let list:string[]=["one","Two","Three"];
let [x,y,z]=list;//destructuring the array values
console.log(x);//one
console.log(y);//two
console.log(z);//three
console.log(`Array values are ${x},${y},${z}`);
let obj={a:"one",b:"two",c:"three"};
let {a,b,c}=obj;//destructuring the object properties
console.log(a);//one
console.log(b);//two
console.log(c);//three