"use strict";
exports.__esModule = true;
var valid = require("./myModules");
var st = new valid.Student(1, "Bala");
var result1 = st.showDetails();
console.log("Studnet Details : " + result1);
var emp = new valid.Employee("Sai_Pallavi", "Vignesh");
var result_2 = emp.showDetails();
console.log("Employee Details : " + result_2);
