function add(x:number,...y:number[]):number{//syntax for rest parameter =[...]parameter name
    let result=x;
    for(var i=0;i<y.length;i++)
    {
        result+=y[i];
    }
    return result;
}
console.log(add(1,2));//3
console.log(add(1,2,3,4));//10
let result=add(2,5);//7
let result2=add(2,5,7,2);//16
console.log(result);
console.log(result2);