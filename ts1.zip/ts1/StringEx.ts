let firstname:string="Balavignesh";
let site:string="www.hsengivalab.com";//string concatenation
let str="Hello, My Name is "+firstname+
" and My Site "+site;
console.log(str);//string interpolation and multiline
let str2=`Hello, 
My Name is ${firstname} and 
My Site is ${site}`;
console.log(str2);