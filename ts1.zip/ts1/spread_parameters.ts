function add(...x:number[]):number{//rest parameters(...x:)
    let result=0;
    for(var i=0;i<x.length;i++)
    {
        result +=x[i];
    }
    return result;
}
let nums:number[]=[2,5,5];
let result1=add(2,3,4,5,6);
let result=add(...nums);//spread operators(...)
console.log(nums);
console.log(result);
console.log(result1);