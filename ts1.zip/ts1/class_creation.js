var Person = /** @class */ (function () {
    function Person(firstname, lastname) {
        this.firstname = firstname;
        this.lastname = lastname;
    }
    return Person;
}());
var p = new Person("Bala", "vignesh");
//p.firstname="Bala";
//p.lastname="vignesh";
console.log(p.firstname + "" + p.lastname);
