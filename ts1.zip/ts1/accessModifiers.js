var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Bala = /** @class */ (function () {
    function Bala() {
    }
    Bala.prototype.saveData = function (bala) {
        this.x = 1;
        this.y = 1;
        this.z = 1;
        bala.x = 1;
        bala.y = 1;
        bala.z = 1;
    };
    return Bala;
}());
var Vignesh = /** @class */ (function (_super) {
    __extends(Vignesh, _super);
    function Vignesh() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Vignesh.prototype.getData = function (bala, vigensh) {
        this.y = 1;
        this.z = 1;
        vigensh.y = 1;
        vigensh.z = 1;
        bala.z = 1;
        bala.x = 1; //error x only accessible within a
        vigensh.x = 1; //error x only accessible within a
        vigensh.y = 1; //error y only accessible through instance
    };
    return Vignesh;
}(Bala));
