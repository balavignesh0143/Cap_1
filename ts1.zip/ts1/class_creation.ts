class Person
{
    firstname;
    lastname;
    constructor(firstname:string,lastname:string)
    {
        this.firstname=firstname;
        this.lastname=lastname;
    }
}
var p=new Person("Bala","vignesh");
//p.firstname="Bala";
//p.lastname="vignesh";

console.log(p.firstname+""+p.lastname);