class Bala{
    private x:number;
    protected y:number;
    public z:number;//by default
    saveData(bala:Bala):void
    {
        this.x=1;//ok
        this.y=1;//ok
        this.z=1;//ok
        bala.x=1;//ok
        bala.y=1;//ok
        bala.z=1;//ok
    }
}
class Vignesh extends Bala{
    getData(bala:Bala,vigensh:Vignesh)
    {
        this.y=1;//ok
        this.z=1;//ok
        vigensh.y=1;//ok
        vigensh.z=1;//ok
        bala.z=1;//ok
        //bala.x=1;//error x only accessible within a
        //vigensh.x=1;//error x only accessible within a
        vigensh.y=1;//error y only accessible through instance
    }
}