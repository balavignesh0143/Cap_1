var Employee = /** @class */ (function () {
    function Employee(eid, ename) {
        //this.eid=eid;
        Employee.eid = eid;
        this.ename = ename;
    }
    Employee.prototype.displayDetails = function () {
        return Employee.eid + " " + this.ename;
    };
    return Employee;
}());
Employee.eid = 12345;
var emp = new Employee(Employee.eid, "Balavignesh");
console.log(emp.displayDetails());
