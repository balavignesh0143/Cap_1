var a = 10;
var b = true;
var c = "Welcome";
function greet() {
    return "Hello! Balavignesh";
}
var greeting = greet();
var greeeting;
greeeting = greet();
console.log(greeeting);
function greet1() {
    return "Hello! Hsengivalab";
}
var greeeting;
greeeting = greet1();
console.log(greeeting);
