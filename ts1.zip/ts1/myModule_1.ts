import * as valid from "./myModules";
let st=new valid.Student(1,"Bala");
let result1=st.showDetails();
console.log("Studnet Details : "+result1);
let emp=new valid.Employee("Sai_Pallavi","Vignesh");
let result_2=emp.showDetails();
console.log("Employee Details : "+result_2);