var a:number=2;
var b:number;
var c:string;
var d:boolean;
var e=undefined;
var f=null;

a=123;
b=20;
c="Balavignesh";
d=false;

console.log(a);
console.log(b);
console.log(c);
console.log(d);
console.log(e);
console.log(f);