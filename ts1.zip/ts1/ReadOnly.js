var Company = /** @class */ (function () {
    function Company(_name) {
        this.country = "India";
        this.name = _name;
    }
    Company.prototype.showDetails = function () {
        console.log(this.name + " : " + this.country);
    };
    return Company;
}());
var c1 = new Company("Capgemini");
c1.showDetails(); //dot net tricks innvoation : india
//c1.name="Infosys";//error name can be initialized only capgemini
