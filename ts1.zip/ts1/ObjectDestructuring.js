var list = ["one", "Two", "Three"];
var x = list[0], y = list[1], z = list[2]; //destructuring the array values
console.log(x); //one
console.log(y); //two
console.log(z); //three
console.log("Array values are " + x + "," + y + "," + z);
var obj = { a: "one", b: "two", c: "three" };
var a = obj.a, b = obj.b, c = obj.c; //destructuring the object properties
console.log(a); //one
console.log(b); //two
console.log(c); //three
