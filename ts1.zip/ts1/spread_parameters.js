function add() {
    var x = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        x[_i] = arguments[_i];
    }
    var result = 0;
    for (var i = 0; i < x.length; i++) {
        result += x[i];
    }
    return result;
}
var nums = [2, 5, 5];
var result1 = add(2, 3, 4, 5, 6);
var result = add.apply(void 0, nums); //spread operators(...)
console.log(nums);
console.log(result);
console.log(result1);
