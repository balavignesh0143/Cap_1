var yes = true;
var no = false;
var a = "Bala";
var b = "Vignesh";
console.log(yes);
console.log(no);
console.log(a);
console.log(b);
