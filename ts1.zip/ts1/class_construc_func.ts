class Employee
{
    static eid:number;
    ename:string;
    constructor(eid:number,ename:string){
        //this.eid=eid;
        Employee.eid=eid;
        this.ename=ename;
    }

    displayDetails()
    {
        return Employee.eid+" "+this.ename;
    }

}

Employee.eid=12345;
var emp=new Employee(Employee.eid,"Balavignesh");
console.log(emp.displayDetails());