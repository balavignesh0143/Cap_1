class Person
{
    private firstname;
    private lastname;
    constructor(_firstname:string,_lastname:string)
    {
        this.firstname=_firstname;
        this.lastname=_lastname;
    }
    fullName():string{
        return this.firstname+""+this.lastname;
    }
}

class Employee extends Person{
    id:number;
    constructor(_id:number,_firstname:string,_lastname:string){
        super(_firstname,_lastname);
        this.id=_id;
    }

    showDetails():void{
        console.log(this.id+" "+this.fullName());
    }
}

let e=new Employee(1,"Bala","vignesh");
e.showDetails();