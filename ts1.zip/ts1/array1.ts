let num=21;
let a1=[1,2,3,'a',true];
var x:number[];
x=[1,2,3,4];
x.push(10);
num=x.pop();
let numberList:number[]=[1,2,3];
let numList:Array<number>=[1,2,3];