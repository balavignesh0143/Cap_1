"use strict";
exports.__esModule = true;
//exporting employee type
var Employee = /** @class */ (function () {
    function Employee(firstname, lastname) {
        this.firstname = firstname;
        this.lastname = lastname;
    }
    Employee.prototype.showDetails = function () {
        return this.firstname + ", " + this.lastname;
    };
    return Employee;
}());
exports.Employee = Employee;
//exporting student type
var Student = /** @class */ (function () {
    function Student(rollno, name) {
        this.rollno = rollno;
        this.name = name;
    }
    Student.prototype.showDetails = function () {
        return this.rollno + ", " + this.name;
    };
    return Student;
}());
exports.Student = Student;
