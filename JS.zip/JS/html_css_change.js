function fun()
{
    var a=document.getElementById("demo");
    a.innerHTML="Welcome to Capgemini";
    a.style.color="red";
    a.style.fontSize="35px";
}