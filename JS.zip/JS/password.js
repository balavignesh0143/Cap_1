function check()
{
    var pass=document.c1.password.value;
    var re=document.c1.re_enter.value;
    if(pass==re)
    {
        window.alert("Password Valid...");
    }
    else
    {
        window.alert("Password Invalid...");
    }
}