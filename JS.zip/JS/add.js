function add()
{
    var a=document.f1.num1.value;
    var b=document.f1.num2.value;
    var c=parseInt(a)+parseInt(b);
    document.write("Addition of two numbers : "+c);
    window.alert("Addition of two numbers : "+c);
}