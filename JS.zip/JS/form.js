function valUN()
{
    var name=document.getElementById("uname").value;
    if(name.length>5)
    {
        document.getElementById("un").style.color="green";
        document.getElementById("un").innerHTML="User name valid...";
    }
    else
    {
        document.getElementById("un").style.color="red";
        document.getElementById("un").innerHTML="User name invalid...";
    }
}
function valName()
{
    var nam=document.getElementById("name");
    nam.value=nam.value.toUpperCase();
    var nam=document.getElementById("name").value;
    if(nam.length>6)
    {
        document.getElementById("n").style.color="green";
        document.getElementById("n").innerHTML="Name valid...";
    }
    else
    {
        document.getElementById("n").style.color="red";
        document.getElementById("n").innerHTML="Name Invalid...";
    }
}
function valMail()
{
    var x=document.getElementById("mail").value;
    var atPosition=x.indexOf("@");
    var dotPosition=x.lastIndexOf(".");
    if(atPosition<1 || dotPosition<atPosition+2 || dotPosition+2>=x.length)
    {
        document.getElementById("m").style.color="red";
        document.getElementById("m").innerHTML="Mail ID invalid...";
    }
    else
    {
        document.getElementById("m").style.color="green";
        document.getElementById("m").innerHTML="Mail ID valid...";
    }
}
function valPd()
{
    var pass=document.getElementById("password").value;
    if(pass.length>=6 && pass.length<=8)
    {
        document.getElementById("pd").style.color="green";
        document.getElementById("pd").innerHTML="Password valid...";
    }
    else
    {
        document.getElementById("pd").style.color="red";
        document.getElementById("pd").innerHTML="Password invalid...";
    }
}
function valPwd()
{
    var pass=document.getElementById("password").value;
    var re=document.getElementById("re_enter").value;
    if(pass==re)
    {
        document.getElementById("p").style.color="green";
        document.getElementById("p").innerHTML="Password match...";
    }
    else
    {
        document.getElementById("p").style.color="red";
        document.getElementById("p").innerHTML="Password mis-match...";
    }
}
function valMblNo()
{
    var mn=document.getElementById("contact").value;
    var a=/[6,7,8,9]+[0-9]{9}/; 
    if(mn.match(a) && mn.length==10)
    {
        document.getElementById("c").style.color="green";
        document.getElementById("c").innerHTML="Valid mobile number...";
    }
    else
    {
        document.getElementById("c").style.color="red";
        document.getElementById("c").innerHTML="Invalid mobile number...";
    }
}
function valDate()
{
    var dat=document.getElementById("date").value;
    var date=new Date(dat);
    var yr=Number(date.getFullYear());
    var dd=2000;
    if(yr>=dd)
    {
        document.getElementById("d").style.color="red";
        document.getElementById("d").innerHTML="DOB invalid...";
    }
    else
    {
        document.getElementById("d").style.color="green";
        document.getElementById("d").innerHTML="DOB valid...";
    }
}

function final()
{
    if(document.getElementById("un").innerHTML=="User name valid..." && document.getElementById("n").innerHTML== "Name valid..." && 
    document.getElementById("m").innerHTML=="Mail ID valid..." && document.getElementById("pd").innerHTML=="Password valid..." && 
    document.getElementById("p").innerHTML=="Password match..." && document.getElementById("c").innerHTML=="Valid mobile number..." &&
    document.getElementById("d").innerHTML=="DOB valid...")
    {
        alert("Registered Successfully...");
        return true;
    }
    else{
        alert("Enter valid details...");
        return false;
    }
}