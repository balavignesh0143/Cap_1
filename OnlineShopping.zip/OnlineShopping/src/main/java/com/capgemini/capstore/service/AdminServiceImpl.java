package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.dao.IAdminDao;
import com.capgemini.capstore.entities.AdminMasterEntity;

@Service
public class AdminServiceImpl implements IAdminService {

	@Autowired
	IAdminDao adminDao;

	@Override
	public AdminMasterEntity createAccount(AdminMasterEntity admin) {
		adminDao.save(admin);
		return adminDao.findById(admin.getAdminId()).get();
	}

	/*@Override
	public List<AdminEntity> viewAllAdmin() {
		return adminDao.findAll();
	}*/

	@Override
	public AdminMasterEntity viewById(long adminId) {
		return adminDao.findById(adminId).get();
	}

}
