package com.capgemini.capstore.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "customerMaster")
public class CustomerMasterEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceId")
	@SequenceGenerator(name = "sequenceId", initialValue = 111111, sequenceName = "customerId") // sequence to be create
																								// // by manually
	@Column(length = 20)
	private long customerId;
	@Column(length = 20)
	private String customerName;
	@Column(length = 20)
	private String customerPassword;
	@Column(length = 20)
	private String customerContactNo;
	@Column(length = 100)
	private String customerAddress;
	@Column(length = 20)
	private String customerStatus;

	/**
	 * @return the cutomerId
	 */
	public long getCustomerId() {
		return customerId;
	}

	/**
	 * @param cutomerId
	 *            the cutomerId to set
	 */
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName
	 *            the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the customerPassword
	 */
	public String getCustomerPassword() {
		return customerPassword;
	}

	/**
	 * @param customerPassword
	 *            the customerPassword to set
	 */
	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}

	/**
	 * @return the customerContactNo
	 */
	public String getCustomerContactNo() {
		return customerContactNo;
	}

	/**
	 * @param customerContactNo
	 *            the customerContactNo to set
	 */
	public void setCustomerContactNo(String customerContactNo) {
		this.customerContactNo = customerContactNo;
	}

	/**
	 * @return the customerAddress
	 */
	public String getCustomerAddress() {
		return customerAddress;
	}

	/**
	 * @param customerAddress
	 *            the customerAddress to set
	 */
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	/**
	 * @return the customerStatus
	 */
	public String getCustomerStatus() {
		return customerStatus;
	}

	/**
	 * @param customerStatus
	 *            the customerStatus to set
	 */
	public void setCustomerStatus(String customerStatus) {
		this.customerStatus = customerStatus;
	}

	/**
	 * @param customerId
	 * @param customerName
	 * @param customerPassword
	 * @param customerContactNo
	 * @param customerAddress
	 * @param customerStatus
	 */
	public CustomerMasterEntity(long customerId, String customerName, String customerPassword, String customerContactNo,
			String customerAddress, String customerStatus) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerPassword = customerPassword;
		this.customerContactNo = customerContactNo;
		this.customerAddress = customerAddress;
		this.customerStatus = customerStatus;
	}

	/**
	 * 
	 */
	public CustomerMasterEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CustomerEntity [customerId=" + customerId + ", customerName=" + customerName + ", customerPassword="
				+ customerPassword + ", customerContactNo=" + customerContactNo + ", customerAddress=" + customerAddress
				+ ", customerStatus=" + customerStatus + "]";
	}
}
