package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.dao.IMerchantDao;
import com.capgemini.capstore.entities.MerchantMasterEntity;

@Service
public class MerchantServiceImpl implements IMerchantService{
		
	@Autowired
	IMerchantDao merchantDao;

	@Override
	public MerchantMasterEntity createAccount(MerchantMasterEntity merchant) {
		merchantDao.save(merchant);
		return merchantDao.findById(merchant.getMerchantId()).get();
	}

	@Override
	public MerchantMasterEntity viewById(long merchantId) {
		return merchantDao.findById(merchantId).get();
	}
	
}
