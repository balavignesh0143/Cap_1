package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.dao.ICustomerDao;
import com.capgemini.capstore.entities.CustomerMasterEntity;

@Service
public class CustomerServiceImpl implements ICustomerService{
	
	@Autowired
	ICustomerDao customerDao;
	
	@Override
	public CustomerMasterEntity createAccount(CustomerMasterEntity customer) {
		customerDao.save(customer);
		return customerDao.findById(customer.getCustomerId()).get();
	}

	@Override
	public CustomerMasterEntity viewById(long customerId) {
		return customerDao.findById(customerId).get();
	}
	
}
