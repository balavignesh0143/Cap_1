package com.capgemini.capstore.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "productFeedback")
public class ProductFeedbackEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(length = 20)
	private long productId;
	@Column(length = 100)
	private String feedBack;
	@Column(length = 20)
	private long customerId;
	@Column(length = 10)
	private int rating;

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getFeedBack() {
		return feedBack;
	}

	public void setFeedBack(String feedBack) {
		this.feedBack = feedBack;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	@Override
	public String toString() {
		return "ProductBean [productId=" + productId + ", feedBack=" + feedBack + ", customerId=" + customerId
				+ ", rating=" + rating + "]";
	}

	public ProductFeedbackEntity(long productId, String feedBack, long customerId, int rating) {
		super();
		this.productId = productId;
		this.feedBack = feedBack;
		this.customerId = customerId;
		this.rating = rating;
	}

	public ProductFeedbackEntity() {
		super();
	}
}