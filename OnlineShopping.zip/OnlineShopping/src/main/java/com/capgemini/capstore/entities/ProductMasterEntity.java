package com.capgemini.capstore.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "productMaster")
public class ProductMasterEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(length = 20)
	private long productId;
	@Column(length = 20)
	private long merchantId;
	@Column(length = 50)
	private String productName;
	@Column(length = 100)
	private String productDescription;
	private int productQuantity;
	@Column(length = 10)
	private double productPrice;
	@Column(length = 20)
	private long categoryId;
	@Column(length = 10)
	private double productDiscount;

	public long getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(long merchantId) {
		this.merchantId = merchantId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(long categoryId) {
		this.categoryId = categoryId;
	}

	public double getProductDiscount() {
		return productDiscount;
	}

	public void setProductDiscount(double productDiscount) {
		this.productDiscount = productDiscount;
	}

	public ProductMasterEntity(long productId, long merchantId, String productName, String productDescription,
			int productQuantity, double productPrice, long categoryId, double productDiscount) {
		super();
		this.productId = productId;
		this.merchantId = merchantId;
		this.productName = productName;
		this.productDescription = productDescription;
		this.productQuantity = productQuantity;
		this.productPrice = productPrice;
		this.categoryId = categoryId;
		this.productDiscount = productDiscount;
	}

	public ProductMasterEntity() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "ProductMaster [productId=" + productId + ", merchantId=" + merchantId + ", productName=" + productName
				+ ", productDescription=" + productDescription + ", productQuantity=" + productQuantity
				+ ", productPrice=" + productPrice + ", categoryId=" + categoryId + ", productDiscount="
				+ productDiscount + "]";
	}

}