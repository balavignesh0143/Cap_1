package com.capgemini.capstore.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="wishList")
public class WishListEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(length = 20)
	private long customerId;

	@Column(length = 20)
	private long productId;

	@Column(length = 20)
	private long wishlistId;

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public long getWishlistId() {
		return wishlistId;
	}

	public void setWishlistId(long wishlistId) {
		this.wishlistId = wishlistId;
	}

	public WishListEntity(long customerId, long productId, long wishlistId) {
		super();
		this.customerId = customerId;
		this.productId = productId;
		this.wishlistId = wishlistId;
	}

	@Override
	public String toString() {
		return "WishListEntity [customerId=" + customerId + ", productId=" + productId + ", wishlistId=" + wishlistId
				+ "]";
	}

}