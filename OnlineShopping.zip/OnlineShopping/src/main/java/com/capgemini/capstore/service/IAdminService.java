package com.capgemini.capstore.service;

import com.capgemini.capstore.entities.AdminMasterEntity;

public interface IAdminService {

	AdminMasterEntity createAccount(AdminMasterEntity admin);

	//List<AdminEntity> viewAllAdmin();

	AdminMasterEntity viewById(long adminId);

}
