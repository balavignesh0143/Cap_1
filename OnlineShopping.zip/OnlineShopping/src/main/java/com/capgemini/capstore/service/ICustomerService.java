package com.capgemini.capstore.service;

import com.capgemini.capstore.entities.CustomerMasterEntity;

public interface ICustomerService {

	CustomerMasterEntity createAccount(CustomerMasterEntity customer);

	CustomerMasterEntity viewById(long customerId);

}
