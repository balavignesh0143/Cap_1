package com.capgemini.capstore.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class CategoryMasterEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(length = 20)
	private long categoryId;
	@Column(length = 20)
	private String categoryGender;
	@Column(length = 20)
	private String categoryType;

	public long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(long categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryGender() {
		return categoryGender;
	}

	public void setCategoryGender(String categoryGender) {
		this.categoryGender = categoryGender;
	}

	public String getCategoryType() {
		return categoryType;
	}

	public void setCategoryType(String categoryType) {
		this.categoryType = categoryType;
	}

	public CategoryMasterEntity() {
        super();
        // TODO Auto-generated constructor stub
    }

	public CategoryMasterEntity(long categoryId, String categoryGender, String categoryType) {
        super();
        this.categoryId = categoryId;
        this.categoryGender = categoryGender;
        this.categoryType = categoryType;
    }

	@Override
	public String toString() {
		return "CategoryMaster [categoryId=" + categoryId + ", categoryGender=" + categoryGender + ", categoryType="
				+ categoryType + "]";
	}

}