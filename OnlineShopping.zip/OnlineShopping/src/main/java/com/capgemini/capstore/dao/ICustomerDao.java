package com.capgemini.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.capstore.entities.CustomerMasterEntity;

public interface ICustomerDao extends JpaRepository<CustomerMasterEntity, Long> {

}
