package com.capgemini.capstore.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="merchantFeedback")
public class MerchantFeedbackEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(length = 20)
	private long merchantId;

	@Column(length = 100)
	private String merchantFeedback;

	public long getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(long merchantId) {
		this.merchantId = merchantId;
	}

	public String getMerchantFeedback() {
		return merchantFeedback;
	}

	public void setMerchantFeedback(String merchantFeedback) {
		this.merchantFeedback = merchantFeedback;
	}

	@Override
	public String toString() {
		return "MerchantFeedback [merchantId=" + merchantId + ", merchantFeedback=" + merchantFeedback + "]";
	}

	public MerchantFeedbackEntity(long merchantId, String merchantFeedback) {
        super();
        this.merchantId = merchantId;
        this.merchantFeedback = merchantFeedback;
    }

	public MerchantFeedbackEntity() {
       
    }

}