package com.capgemini.capstore.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "couponDiscount")
public class CouponDiscountEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(length = 20)
	private long couponId;
	@Column(length = 20)
	private String couponCode;
	@Column(length = 10)
	private float couponPercent;
	@Column(length = 10)
	private String generationDate;
	@Column(length = 10)
	private String expiryDate;

	public long getCouponId() {
		return couponId;
	}

	public void setCouponId(long couponId) {
		this.couponId = couponId;
	}

	public String getCouponCode() {
		return couponCode;
	}

	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}

	public float getCouponPercent() {
		return couponPercent;
	}

	public void setCouponPercent(float couponPercent) {
		this.couponPercent = couponPercent;
	}

	public String getGenerationDate() {
		return generationDate;
	}

	public void setGenerationDate(String generationDate) {
		this.generationDate = generationDate;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public CouponDiscountEntity(long couponId, String couponCode, float couponPercent, String generationDate,
			String expiryDate) {
		super();
		this.couponId = couponId;
		this.couponCode = couponCode;
		this.couponPercent = couponPercent;
		this.generationDate = generationDate;
		this.expiryDate = expiryDate;
	}

	public CouponDiscountEntity() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "CouponDiscount [couponId=" + couponId + ", couponCode=" + couponCode + ", couponPercent="
				+ couponPercent + ", generationDate=" + generationDate + ", expiryDate=" + expiryDate + "]";
	}

}